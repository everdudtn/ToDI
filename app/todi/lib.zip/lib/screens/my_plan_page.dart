import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

class MyPlanPage extends StatefulWidget {
  const MyPlanPage({Key? key}) : super(key: key);

  @override
  State<MyPlanPage> createState() => MyPlanState();
}

class MyPlanState extends State<MyPlanPage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController titleController = TextEditingController();
    String? titleInput;
    DateTime startDate = DateTime.now();
    DateTime endDate = DateTime.now();
    TimeOfDay startTime = TimeOfDay.now();
    TimeOfDay endTime = TimeOfDay.now();

    void addToSchedule(BuildContext context) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: const Color.fromRGBO(254, 255, 209, 1),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: EdgeInsets.all(16.0),
                          child: Text(
                            "일정 추가",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        // 다른 위젯을 오른쪽에 추가할 수 있습니다.
                      ],
                    ),
                    SizedBox(
                      width: 300,
                      child: TextField(
                        decoration: const InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1.0,
                              color: Colors.black,
                            ),
                            borderRadius: BorderRadius.all(
                              Radius.circular(10),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1.0,
                              color: Colors.black,
                            ),
                            borderRadius: BorderRadius.all(
                              Radius.circular(10),
                            ),
                          ),
                          hintText: 'Add to Schedule',
                          labelStyle: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                        controller: titleController,
                        onChanged: (value) {
                          setState(() {
                            titleInput = value;
                          });
                        },
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        color: Colors.white,
                      ),
                      child: Column(
                        children: [
                          const Row(
                            children: [
                              Expanded(
                                  child: SizedBox(
                                height: 5,
                              )),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              const Text(
                                '시작',
                                style: TextStyle(fontSize: 24),
                              ),
                              OutlinedButton(
                                onPressed: () async {
                                  Future<DateTime?> future = showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(2023),
                                    lastDate: DateTime(2030),
                                    initialEntryMode:
                                        DatePickerEntryMode.calendarOnly,
                                    builder:
                                        (BuildContext context, Widget? picker) {
                                      return Theme(
                                        data: ThemeData(),
                                        child: picker!,
                                      );
                                    },
                                  );
                                  future.then((date) {
                                    if (date != null) {
                                      setState(() {
                                        startDate = date;
                                      });
                                    }
                                  });
                                },
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith(
                                          (states) {
                                    // If the button is pressed, return green, otherwise blue
                                    if (states
                                        .contains(MaterialState.pressed)) {
                                      return const Color.fromARGB(
                                          255, 231, 231, 231);
                                    }
                                    return const Color.fromARGB(
                                        255, 231, 231, 231);
                                  }),
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                                child: Text(
                                  DateFormat('yyyy년 MM월 dd일').format(startDate),
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              ),
                              OutlinedButton(
                                onPressed: () async {
                                  Future<TimeOfDay?> time = showTimePicker(
                                    context: context,
                                    initialTime: TimeOfDay.now(),
                                    builder:
                                        (BuildContext context, Widget? picker) {
                                      return Theme(
                                        data: ThemeData(),
                                        child: picker!,
                                      );
                                    },
                                  );
                                  time.then((date) {
                                    if (date != null) {
                                      setState(() {
                                        startTime = date;
                                      });
                                    }
                                  });
                                },
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith(
                                          (states) {
                                    // If the button is pressed, return green, otherwise blue
                                    if (states
                                        .contains(MaterialState.pressed)) {
                                      return const Color.fromARGB(
                                          255, 231, 231, 231);
                                    }
                                    return const Color.fromARGB(
                                        255, 231, 231, 231);
                                  }),
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                                child: Text(
                                  '${startTime.hour}시 ${startTime.minute}분',
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              const Text(
                                '종료',
                                style: TextStyle(fontSize: 24),
                              ),
                              OutlinedButton(
                                onPressed: () async {
                                  Future<DateTime?> future = showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(2023),
                                    lastDate: DateTime(2030),
                                    initialEntryMode:
                                        DatePickerEntryMode.calendarOnly,
                                    builder:
                                        (BuildContext context, Widget? picker) {
                                      return Theme(
                                        data: ThemeData(),
                                        child: picker!,
                                      );
                                    },
                                  );
                                  future.then((date) {
                                    if (date != null) {
                                      setState(() {
                                        endDate = date;
                                      });
                                    }
                                  });
                                },
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith(
                                          (states) {
                                    // If the button is pressed, return green, otherwise blue
                                    if (states
                                        .contains(MaterialState.pressed)) {
                                      return const Color.fromARGB(
                                          255, 231, 231, 231);
                                    }
                                    return const Color.fromARGB(
                                        255, 231, 231, 231);
                                  }),
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                                child: Text(
                                  DateFormat('yyyy년 MM월 dd일').format(endDate),
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              ),
                              OutlinedButton(
                                onPressed: () {
                                  Future<TimeOfDay?> time = showTimePicker(
                                    context: context,
                                    initialTime: TimeOfDay.now(),
                                    builder:
                                        (BuildContext context, Widget? picker) {
                                      return Theme(
                                        data: ThemeData(),
                                        child: picker!,
                                      );
                                    },
                                  );
                                  time.then((date) {
                                    if (date != null) {
                                      setState(() {
                                        endTime = date;
                                      });
                                    }
                                  });
                                  print(endTime);
                                },
                                style: ButtonStyle(
                                  backgroundColor:
                                      MaterialStateProperty.resolveWith(
                                          (states) {
                                    // If the button is pressed, return green, otherwise blue
                                    if (states
                                        .contains(MaterialState.pressed)) {
                                      return const Color.fromARGB(
                                          255, 231, 231, 231);
                                    }
                                    return const Color.fromARGB(
                                        255, 231, 231, 231);
                                  }),
                                  shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                  ),
                                ),
                                child: Text(
                                  '${endTime.hour}시 ${endTime.minute}분',
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        color: Color.fromRGBO(255, 249, 159, 1),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(30),
                          bottomRight: Radius.circular(30),
                        ),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: const Text(
                                '추가하기',
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          });
        },
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color.fromRGBO(255, 249, 159, 1),
        onPressed: () {
          addToSchedule(context);
        }, // 버튼을 누를 경우
        tooltip: 'Add Plan', // 플로팅 액션 버튼 설명
        child: const Icon(
          Icons.add,
          color: Colors.black,
        ), // + 모양 아이콘
      ),
      body: SfCalendar(
        view: CalendarView.month,
        dataSource: MeetingDataSource(_getDataSource()),
        monthViewSettings: const MonthViewSettings(
          showAgenda: true,
          appointmentDisplayMode: MonthAppointmentDisplayMode.appointment,
        ),
        headerDateFormat: "yyyy년 M월",
        appointmentTimeTextFormat: 'HH:mm',
        headerStyle: const CalendarHeaderStyle(
          textAlign: TextAlign.center,
          textStyle: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w600,
          ),
        ),
        appointmentTextStyle: const TextStyle(
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
        headerHeight: 80,
        showNavigationArrow: true,
        showTodayButton: true,
      ),
    );
  }
}

List<Meeting> _getDataSource() {
  final List<Meeting> meetings = <Meeting>[];
  final DateTime today = DateTime.now();
  final DateTime startTime = DateTime(
    today.year,
    today.month,
    today.day,
    9,
    0,
    0,
    // 시간 설정 가능 예) 9,0,0
  );
  final DateTime endTime = startTime.add(const Duration(hours: 2));
  meetings.add(
    Meeting(
      '약속이얌',
      DateTime(
        today.year,
        today.month,
        today.day,
        9,
        0,
        0,
        // 시간 설정 가능 예) 9,0,0
      ),
      endTime,
      const Color(0xFF0F8644),
      false,
    ),
  );
  return meetings;
}

class MeetingDataSource extends CalendarDataSource {
  MeetingDataSource(List<Meeting> source) {
    appointments = source;
  }

  @override
  DateTime getStartTime(int index) {
    return appointments![index].from;
  }

  @override
  DateTime getEndTime(int index) {
    return appointments![index].to;
  }

  @override
  String getSubject(int index) {
    return appointments![index].eventName;
  }

  @override
  Color getColor(int index) {
    return appointments![index].background;
  }

  @override
  bool isAllDay(int index) {
    return appointments![index].isAllDay;
  }
}

class Meeting {
  Meeting(this.eventName, this.from, this.to, this.background, this.isAllDay);

  String eventName;
  DateTime from;
  DateTime to;
  Color background;
  bool isAllDay;
}
