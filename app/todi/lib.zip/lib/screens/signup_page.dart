import 'package:flutter/material.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<SignupPage> {
  TextEditingController idController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  String? idInput, passwordInput, confirmInput, phoneInput;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Image.asset(
              'assets/images/logo.png',
              width: 200,
              height: 200,
            ),
          ),
          const SizedBox(
            height: 50,
          ),
          InputBox(
            name: '아이디',
            controller: idController,
            onChanged: (value) {
              setState(() {
                idInput = value;
              });
            },
          ),
          const SizedBox(
            height: 20,
          ),
          InputBox(
            name: '비밀번호',
            controller: passwordController,
            onChanged: (value) {
              setState(() {
                passwordInput = value;
              });
            },
          ),
          const SizedBox(
            height: 20,
          ),
          InputBox(
            name: '비밀번호 확인',
            controller: passwordController,
            onChanged: (value) {
              setState(() {
                confirmInput = value;
              });
            },
          ),
          const SizedBox(
            height: 20,
          ),
          InputBox(
            name: '전화번호',
            controller: phoneController,
            onChanged: (value) {
              setState(() {
                phoneInput = value;
              });
            },
          ),
          const SizedBox(
            height: 20,
          ),
          OutlinedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ButtonStyle(
              minimumSize: const MaterialStatePropertyAll(Size(150, 60)),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              side: MaterialStateProperty.all<BorderSide>(
                const BorderSide(
                  color: Colors.black, // 테두리의 색상
                  width: 3.0, // 테두리의 두께
                ),
              ),
            ),
            child: const Text(
              '인증',
              style: TextStyle(
                fontSize: 20,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class InputBox extends StatefulWidget {
  final String name;
  final TextEditingController? controller;
  final Function(String)? onChanged;

  const InputBox({
    Key? key,
    required this.name,
    this.controller,
    this.onChanged,
  }) : super(key: key);

  @override
  State<InputBox> createState() => _InputBoxState();
}

class _InputBoxState extends State<InputBox> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 300,
      child: TextField(
        controller: widget.controller,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            enabledBorder: const OutlineInputBorder(
              borderSide: BorderSide(
                width: 3.0,
                color: Colors.black,
              ),
              borderRadius: BorderRadius.all(
                Radius.circular(20),
              ),
            ),
            focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(
                width: 3.0,
                color: Colors.black,
              ),
              borderRadius: BorderRadius.all(
                Radius.circular(20),
              ),
            ),
            labelText: widget.name,
            labelStyle: const TextStyle(color: Colors.black)),
      ),
    );
  }
}
