import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:todi/screens/my_home_page/myDiaryPage/myDiaryPage.dart';
import 'task.dart';
import 'hive_helper.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyHomePage> {
  String input = " ";

  Future<void> _showMyDialog() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: const Color(0xFFFEFFD1),
          contentPadding: const EdgeInsets.only(
            left: 0,
            right: 0,
          ),
          title: const Text('Add to List'),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25),
          ),
          content: Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: SizedBox(
              height: 120,
              child: Column(
                children: [
                  const SizedBox(
                    height: 5,
                  ),
                  SizedBox(
                    width: 270,
                    child: TextField(
                      decoration: const InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                        hintText: '내용을 입력해주세요',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(25),
                          ),
                        ),
                      ),
                      autofocus: true,
                      onChanged: (String text) {
                        input = text;
                      },
                      textInputAction: TextInputAction.send,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    width: 300,
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFF99F),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(25),
                        bottomRight: Radius.circular(25),
                      ),
                    ),
                    child: TextButton(
                      onPressed: () {
                        setState(() {
                          HiveHelper().create(Task(input));
                        });
                        Navigator.of(context).pop();
                      },
                      child: const Text(
                        'Add',
                        style: TextStyle(
                          color: Colors.black87,
                          fontSize: 25,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    double screenWidth = screenSize.width;
    double screenHeight = screenSize.height;

    return FutureBuilder<List<Task>>(
      future: HiveHelper().read(),
      builder: (context, snapshot) {
        List<Task> tasks = snapshot.data ?? [];

        return Scaffold(
          backgroundColor: const Color(0xFFFEFFD1),
          appBar: AppBar(
            backgroundColor: const Color(0xFFFFF99F),
            title: const Text(
              'To do',
              style: TextStyle(
                color: Colors.black87,
              ),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: screenHeight / 14,
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.black,
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: const Text(
                        '명언임',
                        style: TextStyle(
                          fontSize: 40,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenHeight / 60,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.black,
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: const Text(
                        '달력임',
                        style: TextStyle(
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenHeight / 150,
                ),
                Container(
                  height: screenHeight / 5.5,
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 2,
                      color: Colors.black,
                      style: BorderStyle.solid,
                    ),
                  ),
                  child: SfCalendar(
                    view: CalendarView.week,
                    monthViewSettings:
                        const MonthViewSettings(showAgenda: true),
                  ),
                ),
                SizedBox(
                  height: screenHeight / 80,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.black,
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: const Text(
                        'Diary',
                        style: TextStyle(
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenHeight / 150,
                ),
                Container(
                  width: 400,
                  height: screenHeight / 10,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF99F),
                    border: Border.all(
                      width: 2,
                      color: Colors.black,
                      style: BorderStyle.solid,
                    ),
                  ),
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const MyDiaryPage(),
                        ),
                      );
                    },
                    icon: const Icon(
                      Icons.book,
                      size: 30,
                      color: Colors.black,
                    ),
                    label: const Text(
                      '일기 작성하기',
                      style: TextStyle(
                        color: Colors.black87,
                        fontSize: 30,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: screenHeight / 80,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.black,
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: const Text(
                        '오늘 할 일',
                        style: TextStyle(
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenHeight / 150,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      width: screenWidth / 1.3,
                      height: screenHeight / 4.3,
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 2,
                          color: Colors.black,
                          style: BorderStyle.solid,
                        ),
                      ),
                      child: ReorderableListView(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 0, vertical: 0),
                        proxyDecorator: (Widget child, int index,
                            Animation<double> animation) {
                          return TaskTile(task: tasks[index], onDeleted: () {});
                        },
                        children: <Widget>[
                          for (int index = 0; index < tasks.length; index += 1)
                            Padding(
                              key: Key('$index'),
                              padding: const EdgeInsets.all(8.0),
                              child: TaskTile(
                                task: tasks[index],
                                onDeleted: () {
                                  setState(() {});
                                },
                              ),
                            )
                        ],
                        onReorder: (int oldIndex, int newIndex) async {
                          if (oldIndex < newIndex) {
                            newIndex -= 1;
                          }
                          await HiveHelper().reorder(oldIndex, newIndex);
                          setState(() {});
                        },
                      ),
                    ),
                    const SizedBox(
                      width: 7,
                    ),
                    Container(
                      height: screenHeight / 4.3,
                      width: screenWidth / 6,
                      decoration: BoxDecoration(
                          color: const Color(0xFFFFF99F),
                          border: Border.all(
                            width: 2,
                            color: Colors.black,
                            style: BorderStyle.solid,
                          ),
                          borderRadius: BorderRadius.circular(20)),
                      child: IconButton(
                        color: Colors.black54,
                        onPressed: () {
                          _showMyDialog();
                        },
                        icon: const Icon(Icons.create),
                        iconSize: 30,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class TaskTile extends StatefulWidget {
  const TaskTile({
    Key? key,
    required this.task,
    required this.onDeleted,
  }) : super(key: key);

  final Task task;
  final Function onDeleted;

  @override
  State<TaskTile> createState() => _TaskTileState();
}

class _TaskTileState extends State<TaskTile> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: AnimatedContainer(
        constraints: const BoxConstraints(minHeight: 60),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF99F),
          borderRadius: BorderRadius.circular(12),
        ),
        duration: const Duration(milliseconds: 300),
        curve: Curves.fastOutSlowIn,
        child: Row(
          children: [
            Checkbox(
              key: widget.key,
              value: widget.task.finished,
              onChanged: (checked) {
                widget.task.finished = checked!;
                widget.task.save();
                setState(() {});
              },
            ),
            Expanded(
              child: Text(
                widget.task.title,
                style: TextStyle(
                  fontSize: 22,
                  color: Colors.white,
                  decoration: widget.task.finished
                      ? TextDecoration.lineThrough
                      : TextDecoration.none,
                ),
              ),
            ),
            IconButton(
              icon: const Icon(
                Icons.delete,
                color: Colors.black54,
              ),
              onPressed: () {
                widget.task.delete();
                widget.onDeleted();
              },
            )
          ],
        ),
      ),
    );
  }
}
