import 'package:flutter/material.dart';

import 'cardPage.dart';

String diaryTitle = '';
String diaryContent = '';

class MyDiaryPage extends StatefulWidget {
  const MyDiaryPage({super.key});

  @override
  State<MyDiaryPage> createState() => _MyDiaryPageState();
}

class _MyDiaryPageState extends State<MyDiaryPage> {
  List<String> todoList = List.empty(growable: true);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    double screenWidth = screenSize.width;
    double screenHeight = screenSize.height;

    return Scaffold(
      backgroundColor: const Color(0xFFFEFFD1),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFFF99F),
        title: const Text(
          'Diary',
          style: TextStyle(color: Colors.black87),
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: screenHeight / 1.4,
            child: ListView.builder(
              padding: const EdgeInsets.only(top: 15),
              itemCount: todoList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      border: Border.all(
                        width: 1,
                        color: Colors.red,
                      ),
                      borderRadius: const BorderRadius.all(
                        Radius.circular(25),
                      ),
                    ),
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const CardPage(),
                          ),
                        );
                      },
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(10.0),
                        title: Text(todoList[index]),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () {
                            setState(
                              () {
                                todoList.removeAt(index);
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            width: screenWidth / 1.1,
            decoration: BoxDecoration(
                border: Border.all(
              width: 0.5,
            )),
          ),
          SizedBox(
            height: screenHeight / 70,
          ),
          Container(
              width: screenWidth / 1.1,
              height: screenHeight / 8,
              decoration: BoxDecoration(
                color: Colors.black45,
                borderRadius: BorderRadius.circular(25),
              ),
              child: TextButton.icon(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        backgroundColor: const Color(0xFFFEFFD1),
                        contentPadding:
                            const EdgeInsets.only(left: 0, right: 0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(45),
                        ),
                        title: const Text(
                          'Keep a Diary',
                          textAlign: TextAlign.center,
                          style: TextStyle(),
                        ),
                        content: SizedBox(
                          height: screenHeight / 1.2,
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: screenHeight / 100,
                                ),
                                Container(
                                  width: screenHeight / 2.2,
                                  height: screenHeight / 2.3,
                                  decoration: const BoxDecoration(
                                    color: Colors.black54,
                                  ),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.black87.withOpacity(0.5),
                                    ),
                                    child: IconButton(
                                      icon: const Icon(Icons.camera_alt),
                                      color: Colors.white60,
                                      onPressed: () {},
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: screenHeight / 100,
                                ),
                                SizedBox(
                                  width: 250,
                                  child: TextField(
                                    textAlign: TextAlign.center,
                                    decoration: const InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      hintText: '제목을 입력해주세요',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(25),
                                        ),
                                      ),
                                    ),
                                    onChanged: (String value) {
                                      diaryTitle = value;
                                    },
                                  ),
                                ),
                                SizedBox(
                                  height: screenHeight / 100,
                                ),
                                SizedBox(
                                  width: 250,
                                  child: TextField(
                                    maxLines: 5,
                                    decoration: const InputDecoration(
                                      filled: true,
                                      fillColor: Colors.white,
                                      hintText: '내용을 입력해주세요',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(25),
                                        ),
                                      ),
                                    ),
                                    onChanged: (String value) {
                                      diaryContent = value;
                                    },
                                  ),
                                ),
                                SizedBox(
                                  height: screenHeight / 100,
                                ),
                                Center(
                                  child: Container(
                                    width: 300,
                                    height: screenHeight / 13,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFFFF99F),
                                      borderRadius: BorderRadius.only(
                                          bottomLeft: Radius.circular(45),
                                          bottomRight: Radius.circular(45)),
                                    ),
                                    child: TextButton(
                                      onPressed: () {
                                        setState(() {
                                          todoList.add(diaryTitle);
                                        });
                                        Navigator.of(context).pop();
                                      },
                                      child: const Text(
                                        'Add',
                                        style: TextStyle(
                                          fontSize: 25,
                                          color: Colors.black87,
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
                icon: const Icon(
                  Icons.add,
                  size: 40,
                  color: Colors.white,
                ),
                label: const Text(
                  '일기 추가하기',
                  style: TextStyle(
                    fontSize: 25,
                    color: Colors.white,
                  ),
                ),
              ))
        ],
      ),
    );
  }
}
