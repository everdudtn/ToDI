import 'package:flutter/material.dart';

class Setting extends StatefulWidget {
  final Function(bool) loginCallback;
  const Setting({super.key, required this.loginCallback});

  @override
  State<Setting> createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  void logout() {
    widget.loginCallback(false);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextButton(
            onPressed: logout,
            child: const Text(
              'logout',
            ),
          ),
        ],
      ),
    );
  }
}
