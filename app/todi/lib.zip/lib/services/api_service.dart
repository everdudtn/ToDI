import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class AuthenticationService {
  final String baseUrl = 'http://192.168.31.204:8000/ToDI';

  Future<bool> login(String username, String password) async {
    final url = Uri.parse('$baseUrl/user_login/'); // 로그인 URL
    final headers = {'Content-Type': 'application/json'};
    final body =
        jsonEncode({'username': username, 'password': password}); // 요청 본문

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        final access = responseData['access_token'];
        final refresh = responseData['refresh_token'];
        final username = responseData['username'];
        // SecureStorage 인스턴스 생성
        const secureStorage = FlutterSecureStorage();

        // // access_token과 refresh_token을 저장

        // await secureStorage.write(key: 'access_token', value: access);
        // await secureStorage.write(key: 'refresh_token', value: refresh);
        // await secureStorage.write(key: 'username', value: username);
        return true; // 로그인 성공
      } else {
        // 요청 실패 (예: 404 Not Found, 500 Internal Server Error 등)
        return false; // 로그인 실패
      }
    } catch (e) {
      // 예외 발생 (네트워크 오류 등)
      return false; // 로그인 실패
    }
  }
}
// import 'dart:convert';

// import 'package:http/http.dart' as http;
// import 'package:toon/models/webtoon_model.dart';

// class ApiService {
//   static const String baseUrl =
//       "https://webtoon-crawler.nomadcoders.workers.dev";
//   static const String today = "today";

//   static Future<List<WebtoonModel>> getTodaysToons() async {
//     List<WebtoonModel> webtoonInstances = [];
//     final url = Uri.parse('$baseUrl/$today');
//     final response = await http.get(url);
//     if (response.statusCode == 200) {
//       final List<dynamic> webtoons = jsonDecode(response.body);
//       for (var webtoon in webtoons) {
//         webtoonInstances.add(WebtoonModel.fromJson(webtoon));
//       }
//       return webtoonInstances;
//     }
//     throw Exception('Failed to fetch data from the API');
//   }
// }
