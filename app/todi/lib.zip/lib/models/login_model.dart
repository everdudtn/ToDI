class LoginModel {
  final String username, access, refresh;

  LoginModel.fromJson(Map<String, dynamic> json)
      : username = json['username'],
        access = json['access_token'],
        refresh = json['refresh_token'];
}
